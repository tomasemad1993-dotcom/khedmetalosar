package com.khedmetalosar.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.Nullable;
import androidx.webkit.WebViewAssetLoader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_PICKER = 1001;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false); s.setAllowContentAccess(true); s.setBuiltInZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder().addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClient(){ @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){ return loader.shouldInterceptRequest(r.getUrl()); }});
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
                fileCallback = cb; Intent i = p.createIntent();
                try { startActivityForResult(i, FILE_PICKER); } catch(Exception e){ fileCallback=null; cb.onReceiveValue(null); }
                return true;
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface public void downloadFile(String name, String text){
            try {
                byte[] data=text.getBytes(StandardCharsets.UTF_8);
                if(Build.VERSION.SDK_INT>=29){
                    ContentValues cv=new ContentValues(); cv.put(MediaStore.Downloads.DISPLAY_NAME,name); cv.put(MediaStore.Downloads.MIME_TYPE,"application/octet-stream"); cv.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS);
                    Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);
                    if(u!=null){ try(OutputStream os=getContentResolver().openOutputStream(u)){ os.write(data); } }
                } else {
                    if(checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},2002); return; }
                    java.io.File f=new java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),name); try(java.io.FileOutputStream os=new java.io.FileOutputStream(f)){os.write(data);}
                }
            } catch(Exception ignored) {}
        }
    }

    @Override protected void onResume(){ super.onResume(); if(webView!=null) webView.evaluateJavascript("if(window.key && Date.now()-lastActivity>300000){lockApp();}", null); }
    @Override public void onBackPressed(){ if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onActivityResult(int req,int result,@Nullable Intent data){ super.onActivityResult(req,result,data); if(req==FILE_PICKER && fileCallback!=null){ Uri[] r=null; if(result==RESULT_OK && data!=null){ Uri u=data.getData(); if(u!=null) r=new Uri[]{u}; } fileCallback.onReceiveValue(r); fileCallback=null; } }
}
